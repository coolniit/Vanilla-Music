Screenshots have been made with the help of Android's [device art generator](https://developer.android.com/distribute/marketing-tools/device-art-generator).

The app's icon can be found in [../mipmap/icon.svgz](../mipmap/icon.svgz).

For adding images, see [All About Descriptions, Graphics, and Screenshots](https://f-droid.org/en/docs/All_About_Descriptions_Graphics_and_Screenshots/).

Feature graphic background [photograph](https://www.flickr.com/photos/dhilowitz/16596798443/) is licensed CC-BY-2.0.

Feature graphic has been make with [Inkscape](https://inkscape.org/) by including JPG background and SVG image via linking.
