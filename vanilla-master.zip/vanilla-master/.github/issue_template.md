1. Please take a moment to check if the same Bug has already been reported.
2. Please use our subreddit for general questions: https://www.reddit.com/r/vanillamusic/
3. Please provide all relevant information below.

**You MUST delete the content above including this line before posting, otherwise your issue may be closed as 'invalid'.**

- Vanilla Music Version (Settings -> About):
- Android Version:
- Phone vendor / model:
- Application was downloaded from (use `[x]`):
  - [ ] Play Store
  - [ ] F-Droid
  - [ ] Other (Nightly Build)
- Did this work in a previous version?
  - [ ] Yes
  - [ ] No
  - [ ] NA / Don't know.

## Description

....

## Steps to reproduce the issue

...

## Screenshot / Video (If applicable)

...
